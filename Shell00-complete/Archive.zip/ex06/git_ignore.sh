git ls-files -o
