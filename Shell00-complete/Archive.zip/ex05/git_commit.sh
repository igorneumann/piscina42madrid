git log --max-count=5 --pretty=format:"%H"
