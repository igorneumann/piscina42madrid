/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ineumann <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/17 13:56:33 by ineumann          #+#    #+#             */
/*   Updated: 2019/09/18 13:58:45 by ineumann         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char *ft_strstr(char *str, char *to_find);

int main(void)
{
	char str[] = "La pat vem o pato Pata aqui, pata acola";
	char find[] = "pato";

	printf("STRSTR: %s\nFT_STRSTR: %s\nSTRING: %s\nTO_FIND: %s\n", strstr(str, find), ft_strstr(str, find), str, find);
	return (0);
}
