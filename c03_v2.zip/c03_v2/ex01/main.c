/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ineumann <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/16 20:29:53 by ineumann          #+#    #+#             */
/*   Updated: 2019/09/18 11:23:13 by ineumann         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <string.h>

int ft_strncmp(char *s1, char *s2, unsigned int n);

int main(void)
{
	char a[] = "abc";
	char b[] = "abd";
	int n = 0;

	printf("STRNCP = %i\nFT_STRNCP = %i", strncmp(a, b, n), ft_strncmp(a, b, n));
	return(0);
}
