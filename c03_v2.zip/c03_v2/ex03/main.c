/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ineumann <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/17 10:28:59 by ineumann          #+#    #+#             */
/*   Updated: 2019/09/18 13:20:30 by ineumann         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <string.h>

char	*ft_strncat(char *dest, char *src, unsigned int nb);

int		main(void)
{
	char	source[] = "or not to be";
	char	dest[30] = "To be ";
	char	dest2[30] = "To be ";
	int		n = 2147483647;

	printf("ORIGINAL: %s\nDESTINY: %s\nDESTINY FT: %s\n", source, strncat(&dest[0], &source[0], n), ft_strncat(&dest2[0], &source[0], n));
	return (0);
}
