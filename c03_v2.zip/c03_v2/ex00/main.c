/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ineumann <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/16 17:06:55 by ineumann          #+#    #+#             */
/*   Updated: 2019/09/17 21:58:23 by ineumann         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <string.h>

int		ft_strcmp(char *s1, char *s2);

int		main(void)
{
	char a[] = "prueba";
	char b[] = "pruEba";

	printf("El valor retornado por strcmp es %u\n El valor retornado por mi funcion es %u\n", strcmp(a, b), ft_strcmp(a, b));
	return (0);
}
