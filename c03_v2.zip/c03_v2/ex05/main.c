/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ineumann <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/17 17:35:21 by ineumann          #+#    #+#             */
/*   Updated: 2019/09/18 15:13:29 by ineumann         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

unsigned int ft_strlcat(char *dest, char *src, unsigned int size);

int main(void)
{
	char src[] = " cagou na caneca";
	char dest[40] = "O pato pateta";
	char dest2[40] = "O pato pateta";
	int n = 15;

	printf("ORIG: %s\nCOPY: %s\nSTRLCAT: %lu\n", src, dest, strlcat(dest, src, n));	
	printf("ORIG: %s\nFT_COPY: %s\nFT_STRLCAT: %u\n", src, dest2, ft_strlcat(dest2, src, n));
	return (0);
}
