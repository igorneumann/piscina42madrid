/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ineumann <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/17 11:50:38 by ineumann          #+#    #+#             */
/*   Updated: 2019/09/18 12:41:31 by ineumann         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char *ft_strcat(char *dest, char *src);

int		main(void)
{
	char	source[] = "or not to be";
	char	dest[30] = "To be ";
	char	dest2[30] = "To be ";

	printf("ORIGINAL: %s\nDESTINY: %s\nDESTINY FT: %s\n", source, strcat(&dest[0], &source[0]), ft_strcat(&dest2[0], &source[0]));
	return (0);
}
